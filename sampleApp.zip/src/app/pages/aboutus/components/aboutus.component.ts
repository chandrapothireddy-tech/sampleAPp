import { Component } from "@angular/core";
@Component({
    selector:"aboutus",
    templateUrl:"../partials/aboutus.component.html"
})
export class AboutusComponent{

}