import { Component } from "@angular/core";
@Component({
    selector:"menu",
    templateUrl:"../partials/menu.component.html"
})
export class MenuComponent{

    
}