export class Item{
    name:String;
    quantity:Number;
    date:Date;
    price:Number
}