import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Item } from '../models/item';
import { Observable } from 'rxjs';

@Injectable()
export class ItemService{
    constructor(private http:HttpClient){}
    addItem(item:Item){
        return this.http.post("/api/addItem",item);
    }
    getItems():Observable<Item[]>{
        return this.http.get<Item[]>("/api/listitems");
    }
}