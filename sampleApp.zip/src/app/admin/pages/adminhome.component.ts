import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'adminHome',
    templateUrl: 'adminHome.component.html'
})

export class AdminHomeComponent implements OnInit {
    constructor() { }

    ngOnInit() { }
}