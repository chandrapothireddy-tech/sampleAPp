import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'adminContact',
    templateUrl: 'admin.contact.component.html'
})

export class AdminContactComponent implements OnInit {
    constructor() { }

    ngOnInit() { }
}