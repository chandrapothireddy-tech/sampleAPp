import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'adminMenu',
    templateUrl: 'adminMenu.component.html'
})

export class AdminMenuComponent implements OnInit {
    constructor() { }

    ngOnInit() { }
}