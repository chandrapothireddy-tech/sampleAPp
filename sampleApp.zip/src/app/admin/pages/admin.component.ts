import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'adminComponent',
    templateUrl: 'adminComponent.component.html'
})

export class AdminComponent implements OnInit {
    constructor() { }

    ngOnInit() { }
}