module.exports={
    local:{
        db:"mongodb://localhost/trainDb",
        secret: 'keyboard cat'
    },
    prod:{
        db:"mongodb://10.112.21.23/trainDb"
    }
}